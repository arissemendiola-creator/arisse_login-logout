﻿
using System;
using System.Security.Cryptography;

namespace arisselogin
{
    public static class PasswordHasher
    {
        public static string GenerateSalt()
        {
            byte[] salt = RandomNumberGenerator.GetBytes(16);
            return Convert.ToBase64String(salt);
        }

        public static string HashPassword(string password, string salt)
        {
            byte[] saltBytes = Convert.FromBase64String(salt);

            byte[] hash = Rfc2898DeriveBytes.Pbkdf2(
                password,
                saltBytes,
                100000,
                HashAlgorithmName.SHA256,
                32);

            return Convert.ToBase64String(hash);
        }

        public static bool VerifyPassword(
            string password, string salt, string storedHash)
        {
            try
            {
                string newHash = HashPassword(password, salt);

                return CryptographicOperations.FixedTimeEquals(
                    Convert.FromBase64String(newHash),
                    Convert.FromBase64String(storedHash));
            }
            catch (FormatException)
            {
                return false;
            }
        }
    }
}
