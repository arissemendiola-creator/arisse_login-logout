﻿
using System;
using System.Data.OleDb;
using System.IO;

namespace arisselogin
{
    public static class DatabaseHelper
    {
        private static readonly string dbPath =
            Path.GetFullPath(Path.Combine(
                AppDomain.CurrentDomain.BaseDirectory,
                "..", "..", "..", "arissedatabase.accdb"));

        private static readonly string connectionString =
            $@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={dbPath};";

        public static OleDbConnection GetConnection()
        {
            return new OleDbConnection(connectionString);
        }

        public static void CreateUsersTable()
        {
            if (!File.Exists(dbPath))
                throw new FileNotFoundException(
                    "arissedatabase.accdb was not found. Place it in your project folder.");

            using (OleDbConnection con = GetConnection())
            {
                con.Open();

                try
                {
                    using (OleDbCommand check = new OleDbCommand(
                        "SELECT TOP 1 UserID FROM Users", con))
                    {
                        check.ExecuteScalar();
                    }
                }
                catch (OleDbException)
                {
                    string sql = @"CREATE TABLE Users (
                        UserID AUTOINCREMENT PRIMARY KEY,
                        FullName TEXT(100),
                        Username TEXT(50),
                        PasswordHash TEXT(255),
                        PasswordSalt TEXT(255),
                        CreatedAt DATETIME
                    )";

                    using (OleDbCommand create = new OleDbCommand(sql, con))
                    {
                        create.ExecuteNonQuery();
                    }
                }
            }
        }

        public static bool TestConnection()
        {
            try
            {
                using (OleDbConnection con = GetConnection())
                {
                    con.Open();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        public static bool RegisterUser(
            string fullName, string username, string password)
        {
            CreateUsersTable();

            using (OleDbConnection con = GetConnection())
            {
                con.Open();

                string checkSql =
                    "SELECT COUNT(*) FROM Users WHERE Username = ?";

                using (OleDbCommand check = new OleDbCommand(checkSql, con))
                {
                    check.Parameters.Add("?", OleDbType.VarWChar, 50).Value =
                        username;

                    int count = Convert.ToInt32(check.ExecuteScalar());

                    if (count > 0)
                        return false;
                }

                string salt = PasswordHasher.GenerateSalt();
                string hash = PasswordHasher.HashPassword(password, salt);

                string insertSql = @"INSERT INTO Users
                    (FullName, Username, PasswordHash, PasswordSalt, CreatedAt)
                    VALUES (?, ?, ?, ?, ?)";

                using (OleDbCommand cmd = new OleDbCommand(insertSql, con))
                {
                    cmd.Parameters.Add("?", OleDbType.VarWChar, 100).Value = fullName;
                    cmd.Parameters.Add("?", OleDbType.VarWChar, 50).Value = username;
                    cmd.Parameters.Add("?", OleDbType.VarWChar, 255).Value = hash;
                    cmd.Parameters.Add("?", OleDbType.VarWChar, 255).Value = salt;
                    cmd.Parameters.Add("?", OleDbType.Date).Value = DateTime.Now;

                    cmd.ExecuteNonQuery();
                }

                return true;
            }
        }

        public static string? LoginUser(string username, string password)
        {
            CreateUsersTable();

            using (OleDbConnection con = GetConnection())
            {
                con.Open();

                string sql = @"SELECT FullName, PasswordHash, PasswordSalt
                    FROM Users WHERE Username = ?";

                using (OleDbCommand cmd = new OleDbCommand(sql, con))
                {
                    cmd.Parameters.Add("?", OleDbType.VarWChar, 50).Value =
                        username;

                    using (OleDbDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string fullName =
                                reader["FullName"]?.ToString() ?? "";

                            string storedHash =
                                reader["PasswordHash"]?.ToString() ?? "";

                            string salt =
                                reader["PasswordSalt"]?.ToString() ?? "";

                            if (string.IsNullOrEmpty(storedHash) ||
                                string.IsNullOrEmpty(salt))
                            {
                                return null;
                            }

                            if (PasswordHasher.VerifyPassword(
                                password, salt, storedHash))
                            {
                                return fullName;
                            }
                        }
                    }
                }
            }

            return null;
        }
    }
}
