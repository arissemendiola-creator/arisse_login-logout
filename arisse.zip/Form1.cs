
using System;
using System.Drawing;
using System.Windows.Forms;

namespace arisselogin
{
    public partial class Form1 : Form
    {
        private readonly Color violet = Color.FromArgb(112, 70, 170);
        private TextBox txtUsername = null!;
        private TextBox txtPassword = null!;

        public Form1()
        {
            InitializeComponent();
            BuildLoginForm();
        }

        private void BuildLoginForm()
        {
            Text = "Arisse Login";
            ClientSize = new Size(430, 540);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            BackColor = Color.FromArgb(248, 245, 252);

            Label title = new Label()
            {
                Text = "ARISSE LOGIN",
                Font = new Font("Segoe UI", 23, FontStyle.Bold),
                ForeColor = violet,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(40, 45),
                Size = new Size(350, 45)
            };

            Label welcome = new Label()
            {
                Text = "Welcome Back!",
                Font = new Font("Segoe UI", 17, FontStyle.Bold),
                ForeColor = Color.FromArgb(55, 45, 65),
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(40, 120),
                Size = new Size(350, 35)
            };

            Label description = new Label()
            {
                Text = "Please log in to your account.",
                Font = new Font("Segoe UI", 10),
                ForeColor = Color.Gray,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(40, 155),
                Size = new Size(350, 25)
            };

            Label userLabel = MakeLabel("Username", 65, 220);
            txtUsername = MakeTextBox(65, 250);

            Label passLabel = MakeLabel("Password", 65, 300);
            txtPassword = MakeTextBox(65, 330);
            txtPassword.UseSystemPasswordChar = true;

            Button login = MakeButton("LOGIN", 65, 395);
            login.Click += Login_Click;

            Button register = new Button()
            {
                Text = "Create New Account",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = violet,
                BackColor = Color.Transparent,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(65, 450),
                Size = new Size(300, 35),
                Cursor = Cursors.Hand
            };

            register.FlatAppearance.BorderSize = 0;
            register.Click += Register_Click;

            Button test = new Button()
            {
                Text = "Test Database Connection",
                Font = new Font("Segoe UI", 8),
                ForeColor = Color.Gray,
                BackColor = Color.Transparent,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(115, 490),
                Size = new Size(200, 25)
            };

            test.FlatAppearance.BorderSize = 0;
            test.Click += TestConnection_Click;

            Controls.AddRange(new Control[]
            {
                title, welcome, description,
                userLabel, txtUsername,
                passLabel, txtPassword,
                login, register, test
            });
        }

        private Label MakeLabel(string text, int x, int y)
        {
            return new Label()
            {
                Text = text,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = Color.FromArgb(65, 55, 75),
                Location = new Point(x, y),
                Size = new Size(300, 25)
            };
        }

        private TextBox MakeTextBox(int x, int y)
        {
            return new TextBox()
            {
                Font = new Font("Segoe UI", 11),
                Location = new Point(x, y),
                Size = new Size(300, 35),
                BorderStyle = BorderStyle.FixedSingle
            };
        }

        private Button MakeButton(string text, int x, int y)
        {
            Button button = new Button()
            {
                Text = text,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = violet,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(x, y),
                Size = new Size(300, 42),
                Cursor = Cursors.Hand
            };

            button.FlatAppearance.BorderSize = 0;
            return button;
        }

        private void Login_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUsername.Text) ||
                string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Please enter your username and password.");
                return;
            }

            try
            {
                string? fullName = DatabaseHelper.LoginUser(
                    txtUsername.Text.Trim(),
                    txtPassword.Text);

                if (fullName != null)
                {
                    MessageBox.Show("Login successful! Welcome " + fullName);

                    txtPassword.Clear();

                    using (Form3 dashboard = new Form3(fullName))
                    {
                        dashboard.ShowDialog();
                    }
                }
                else
                {
                    MessageBox.Show("Incorrect username or password.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Login Error");
            }
        }

        private void Register_Click(object? sender, EventArgs e)
        {
            using (Form2 registration = new Form2())
            {
                registration.ShowDialog();
            }
        }

        private void TestConnection_Click(object? sender, EventArgs e)
        {
            try
            {
                DatabaseHelper.CreateUsersTable();

                MessageBox.Show(
                    "Access database connected successfully!",
                    "Connection Test",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Connection Error");
            }
        }
    }
}
