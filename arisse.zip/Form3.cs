﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace arisselogin
{
    public partial class Form3 : Form
    {
        private readonly Color violet = Color.FromArgb(112, 70, 170);
        private readonly string fullName;

        public Form3(string name)
        {
            InitializeComponent();

            fullName = name;
            BuildDashboard();
        }

        private void BuildDashboard()
        {
            Text = "Arisse Dashboard";
            ClientSize = new Size(500, 350);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            BackColor = Color.FromArgb(248, 245, 252);

            Label title = new Label()
            {
                Text = "DASHBOARD",
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                ForeColor = violet,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(50, 65),
                Size = new Size(400, 50)
            };

            Label welcome = new Label()
            {
                Text = "Welcome, " + fullName + "!",
                Font = new Font("Segoe UI", 17, FontStyle.Bold),
                ForeColor = Color.FromArgb(65, 55, 75),
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(50, 145),
                Size = new Size(400, 40)
            };

            Label message = new Label()
            {
                Text = "You have successfully logged in.",
                Font = new Font("Segoe UI", 10),
                ForeColor = Color.Gray,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(50, 190),
                Size = new Size(400, 30)
            };

            Button logout = new Button()
            {
                Text = "LOGOUT",
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = violet,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(100, 250),
                Size = new Size(300, 42),
                Cursor = Cursors.Hand
            };

            logout.FlatAppearance.BorderSize = 0;
            logout.Click += (s, e) => Close();

            Controls.AddRange(new Control[]
            {
                title, welcome, message, logout
            });
        }
    }
}
