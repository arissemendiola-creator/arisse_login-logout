﻿
using System;
using System.Drawing;
using System.Windows.Forms;

namespace arisselogin
{
    public partial class Form2 : Form
    {
        private readonly Color violet = Color.FromArgb(112, 70, 170);

        private TextBox txtFullName = null!;
        private TextBox txtUsername = null!;
        private TextBox txtPassword = null!;
        private TextBox txtConfirmPassword = null!;

        public Form2()
        {
            InitializeComponent();
            BuildRegistrationForm();
        }

        private void BuildRegistrationForm()
        {
            Text = "Arisse Registration";
            ClientSize = new Size(430, 570);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            BackColor = Color.FromArgb(248, 245, 252);

            Label title = new Label()
            {
                Text = "CREATE ACCOUNT",
                Font = new Font("Segoe UI", 22, FontStyle.Bold),
                ForeColor = violet,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(30, 35),
                Size = new Size(370, 45)
            };

            txtFullName = AddField("Full Name", 105);
            txtUsername = AddField("Username", 190);
            txtPassword = AddField("Password", 275);
            txtConfirmPassword = AddField("Confirm Password", 360);

            txtPassword.UseSystemPasswordChar = true;
            txtConfirmPassword.UseSystemPasswordChar = true;

            Button register = new Button()
            {
                Text = "REGISTER",
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                ForeColor = Color.White,
                BackColor = violet,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(65, 445),
                Size = new Size(300, 42),
                Cursor = Cursors.Hand
            };

            register.FlatAppearance.BorderSize = 0;
            register.Click += Register_Click;

            Button back = new Button()
            {
                Text = "Back to Login",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = violet,
                BackColor = Color.Transparent,
                FlatStyle = FlatStyle.Flat,
                Location = new Point(65, 495),
                Size = new Size(300, 35)
            };

            back.FlatAppearance.BorderSize = 0;
            back.Click += (s, e) => Close();

            Controls.Add(title);
            Controls.Add(register);
            Controls.Add(back);
        }

        private TextBox AddField(string label, int y)
        {
            Label fieldLabel = new Label()
            {
                Text = label,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = Color.FromArgb(65, 55, 75),
                Location = new Point(65, y),
                Size = new Size(300, 23)
            };

            TextBox field = new TextBox()
            {
                Font = new Font("Segoe UI", 11),
                Location = new Point(65, y + 25),
                Size = new Size(300, 32),
                BorderStyle = BorderStyle.FixedSingle
            };

            Controls.Add(fieldLabel);
            Controls.Add(field);

            return field;
        }

        private void Register_Click(object? sender, EventArgs e)
        {
            string fullName = txtFullName.Text.Trim();
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;
            string confirmPassword = txtConfirmPassword.Text;

            if (string.IsNullOrWhiteSpace(fullName) ||
                string.IsNullOrWhiteSpace(username) ||
                string.IsNullOrWhiteSpace(password) ||
                string.IsNullOrWhiteSpace(confirmPassword))
            {
                MessageBox.Show("Please complete all fields.");
                return;
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("Passwords do not match.");
                return;
            }

            if (password.Length < 6)
            {
                MessageBox.Show("Password must contain at least 6 characters.");
                return;
            }

            try
            {
                bool registered = DatabaseHelper.RegisterUser(
                    fullName, username, password);

                if (registered)
                {
                    MessageBox.Show(
                        "Registration successful! You can now log in.",
                        "Success",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);

                    Close();
                }
                else
                {
                    MessageBox.Show("That username is already registered.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Registration Error");
            }
        }
    }
}
